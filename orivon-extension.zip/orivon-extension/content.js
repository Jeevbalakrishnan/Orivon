// ============================================================
// ORIVON — content.js
// Injected into monitored pages. Shows an overlay warning
// banner directly on the page when thresholds are hit.
// ============================================================

let _bannerEl    = null;
let _lastState   = null;

// Listen for messages from background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'TICK' && msg.warnState !== _lastState) {
    _lastState = msg.warnState;
    if (msg.warnState === 'reminder') _showBanner('reminder', msg.elapsed);
    if (msg.warnState === 'warning')  _showBanner('warning',  msg.elapsed);
    if (msg.warnState === 'blocked')  _showBanner('blocked',  msg.elapsed);
  }
});

function _showBanner(level, elapsed) {
  _removeBanner();

  const configs = {
    reminder: {
      bg: 'linear-gradient(90deg,#1a1200,#332500)',
      border: '#ffd200',
      icon: '⏰',
      text: `<strong>Orivon Reminder:</strong> You've been here for ${_fmt(elapsed)}. Consider taking a break.`,
      btn: '#ffd200',
      btnText: 'Dismiss'
    },
    warning: {
      bg: 'linear-gradient(90deg,#1a0800,#330d00)',
      border: '#ff8c00',
      icon: '⚠️',
      text: `<strong>Orivon Warning:</strong> Excessive usage detected (${_fmt(elapsed)}). Please reduce screen time!`,
      btn: '#ff8c00',
      btnText: 'I Understand'
    },
    blocked: {
      bg: 'linear-gradient(90deg,#1a0008,#330010)',
      border: '#ff2d5b',
      icon: '🚫',
      text: `<strong>Orivon:</strong> This site is being blocked due to excessive usage. You will be redirected.`,
      btn: '#ff2d5b',
      btnText: 'OK'
    }
  };

  const c = configs[level];
  const div = document.createElement('div');
  div.id = 'orivon-banner';
  div.innerHTML = `
    <div style="display:flex;align-items:center;gap:12px;flex:1">
      <span style="font-size:22px">${c.icon}</span>
      <span style="font-family:system-ui,sans-serif;font-size:13px;color:#fff;line-height:1.5">${c.text}</span>
    </div>
    <button id="orivon-dismiss" style="
      background:${c.btn};color:#000;border:none;border-radius:6px;
      padding:7px 16px;font-size:11px;font-weight:700;
      letter-spacing:0.08em;cursor:pointer;white-space:nowrap;
      font-family:system-ui,sans-serif;text-transform:uppercase
    ">${c.btnText}</button>
  `;
  div.style.cssText = `
    position:fixed;top:0;left:0;right:0;z-index:2147483647;
    background:${c.bg};
    border-bottom:2px solid ${c.border};
    padding:12px 20px;
    display:flex;align-items:center;gap:16px;
    box-shadow:0 4px 30px rgba(0,0,0,0.5);
    animation:orivonSlide 0.35s ease forwards;
  `;

  // Inject keyframe
  if (!document.getElementById('orivon-style')) {
    const st = document.createElement('style');
    st.id = 'orivon-style';
    st.textContent = `
      @keyframes orivonSlide {
        from { transform:translateY(-100%); opacity:0; }
        to   { transform:translateY(0);    opacity:1; }
      }
    `;
    document.head.appendChild(st);
  }

  document.body.appendChild(div);
  _bannerEl = div;

  div.querySelector('#orivon-dismiss').addEventListener('click', _removeBanner);

  // Auto-remove reminder after 6s
  if (level === 'reminder') setTimeout(_removeBanner, 6000);
}

function _removeBanner() {
  if (_bannerEl) { _bannerEl.remove(); _bannerEl = null; }
}

function _fmt(s) {
  return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
}
