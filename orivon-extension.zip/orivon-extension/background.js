// ============================================================
// ORIVON Chrome Extension — background.js
// Core tracking engine: detects real tab activity, tracks time,
// fires warnings, enforces locks.
// ============================================================

// ── Monitored sites registry ──────────────────────────────
const SITES = [
  { id: 'youtube',   name: 'YouTube',   pattern: /youtube\.com/,   icon: '▶️',  color: '#ff0000' },
  { id: 'instagram', name: 'Instagram', pattern: /instagram\.com/, icon: '📸', color: '#e1306c' },
  { id: 'facebook',  name: 'Facebook',  pattern: /facebook\.com/,  icon: '👥', color: '#1877f2' },
  { id: 'tiktok',    name: 'TikTok',    pattern: /tiktok\.com/,    icon: '🎵', color: '#010101' },
  { id: 'twitter',   name: 'Twitter/X', pattern: /twitter\.com|x\.com/, icon: '🐦', color: '#1da1f2' },
  { id: 'reddit',    name: 'Reddit',    pattern: /reddit\.com/,    icon: '🤖', color: '#ff4500' },
  { id: 'twitch',    name: 'Twitch',    pattern: /twitch\.tv/,     icon: '🎮', color: '#9146ff' },
];

// ── Thresholds (seconds) ──────────────────────────────────
const THRESHOLDS = { REMINDER: 30, WARNING: 50, BLOCK: 60 };
const LOCK_DURATION = 300; // 5 minutes

// ── Runtime state (in-memory) ─────────────────────────────
// Persisted to chrome.storage.local for popup access
let _sessions    = {};   // { siteId: { elapsed, warnState, activeTabId } }
let _locks       = {};   // { siteId: expiryTimestamp }
let _activeTabId = null;
let _activeSiteId= null;
let _tickInterval= null;

// ── Init: load persisted state ────────────────────────────
chrome.storage.local.get(['sessions','locks'], (data) => {
  _sessions = data.sessions || {};
  _locks    = data.locks    || {};
  // Clean expired locks
  const now = Date.now();
  for (const id of Object.keys(_locks)) {
    if (_locks[id] <= now) delete _locks[id];
  }
  _persist();
  _startTickLoop();
});

// ── Tick loop: runs every second ──────────────────────────
function _startTickLoop() {
  if (_tickInterval) clearInterval(_tickInterval);
  _tickInterval = setInterval(_tick, 1000);
}

function _tick() {
  if (!_activeSiteId) return;
  const site = _getSite(_activeSiteId);
  if (!site) return;

  // If this site just got locked mid-session, stop
  if (_isLocked(_activeSiteId)) {
    _activeSiteId = null;
    _persist();
    return;
  }

  const sess = _getSession(_activeSiteId);
  sess.elapsed++;

  // Fire warning events
  if (sess.elapsed >= THRESHOLDS.BLOCK && sess.warnState !== 'blocked') {
    sess.warnState = 'blocked';
    _onBlocked(site);
  } else if (sess.elapsed >= THRESHOLDS.WARNING && sess.warnState === 'reminder') {
    sess.warnState = 'warning';
    _onWarning(site);
  } else if (sess.elapsed >= THRESHOLDS.REMINDER && sess.warnState === 'normal') {
    sess.warnState = 'reminder';
    _onReminder(site);
  }

  _persist();

  // Broadcast tick to popup if open
  chrome.runtime.sendMessage({
    type: 'TICK',
    siteId: _activeSiteId,
    elapsed: sess.elapsed,
    warnState: sess.warnState,
    sessions: _sessions,
    locks: _getLockRemaining()
  }).catch(()=>{}); // popup may not be open — ignore
}

// ── Warning handlers ──────────────────────────────────────
function _onReminder(site) {
  chrome.notifications.create(`reminder_${site.id}_${Date.now()}`, {
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: '⏰ Orivon Reminder',
    message: `You've been on ${site.name} for 30 seconds. Consider a break.`,
    priority: 1
  });
  _log(site.id, 'Reminder issued', 'warn');
}

function _onWarning(site) {
  chrome.notifications.create(`warning_${site.id}_${Date.now()}`, {
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: '⚠️ Orivon Warning',
    message: `Excessive usage on ${site.name} detected! Please reduce screen time.`,
    priority: 2
  });
  _log(site.id, 'Warning issued — excessive usage', 'danger');
}

function _onBlocked(site) {
  // Lock the site
  _locks[site.id] = Date.now() + LOCK_DURATION * 1000;
  _activeSiteId   = null;

  // Notify
  chrome.notifications.create(`blocked_${site.id}_${Date.now()}`, {
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: '🚫 Orivon — Site Blocked',
    message: `${site.name} has been blocked for 5 minutes due to excessive usage.`,
    priority: 2
  });
  _log(site.id, `Site blocked for 5 minutes`, 'locked');

  // Redirect active tab to blocked page
  if (_activeTabId) {
    chrome.tabs.update(_activeTabId, {
      url: chrome.runtime.getURL(`blocked.html?site=${site.id}&name=${encodeURIComponent(site.name)}`)
    }).catch(()=>{});
  }

  _persist();
}

// ── Tab event listeners ───────────────────────────────────

// When user activates a tab
chrome.tabs.onActivated.addListener(async (info) => {
  try {
    const tab = await chrome.tabs.get(info.tabId);
    _handleTabChange(tab);
  } catch(e) {}
});

// When a tab's URL changes (navigation)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.active) {
    _handleTabChange(tab);
  }
});

// When tab is closed
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === _activeTabId) {
    _activeSiteId = null;
    _activeTabId  = null;
    _persist();
  }
});

// When Chrome window focus changes
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    // Chrome lost focus — pause tracking
    _activeSiteId = null;
    _persist();
    return;
  }
  try {
    const [tab] = await chrome.tabs.query({ active: true, windowId });
    if (tab) _handleTabChange(tab);
  } catch(e) {}
});

function _handleTabChange(tab) {
  if (!tab || !tab.url) return;
  const site = _matchSite(tab.url);
  _activeTabId = tab.id;

  if (!site) {
    // Not a monitored site
    _activeSiteId = null;
    _persist();
    return;
  }

  // Site is locked?
  if (_isLocked(site.id)) {
    _activeSiteId = null;
    // Redirect to blocked page
    chrome.tabs.update(tab.id, {
      url: chrome.runtime.getURL(`blocked.html?site=${site.id}&name=${encodeURIComponent(site.name)}&rem=${_getLockRemaining()[site.id]||300}`)
    }).catch(()=>{});
    return;
  }

  // Switch active site
  if (_activeSiteId !== site.id) {
    _activeSiteId = site.id;
    // Init session if new
    if (!_sessions[site.id]) {
      _sessions[site.id] = { elapsed: 0, warnState: 'normal' };
      _log(site.id, `Session started: ${site.name}`, 'info');
    } else {
      _log(site.id, `Resumed: ${site.name} (${_sessions[site.id].elapsed}s elapsed)`, 'info');
    }
    _persist();
  }
}

// ── Helpers ───────────────────────────────────────────────
function _matchSite(url) {
  for (const s of SITES) {
    if (s.pattern.test(url)) return s;
  }
  return null;
}

function _getSite(id) { return SITES.find(s => s.id === id) || null; }

function _getSession(id) {
  if (!_sessions[id]) _sessions[id] = { elapsed: 0, warnState: 'normal' };
  return _sessions[id];
}

function _isLocked(id) {
  if (!_locks[id]) return false;
  if (Date.now() < _locks[id]) return true;
  delete _locks[id];
  return false;
}

function _getLockRemaining() {
  const out = {};
  for (const [id, exp] of Object.entries(_locks)) {
    const rem = Math.ceil((exp - Date.now()) / 1000);
    if (rem > 0) out[id] = rem;
    else delete _locks[id];
  }
  return out;
}

function _log(siteId, text, type) {
  chrome.storage.local.get(['activityLog'], (data) => {
    const log = data.activityLog || [];
    log.unshift({ time: new Date().toTimeString().slice(0,8), text, type, siteId });
    if (log.length > 100) log.length = 100;
    chrome.storage.local.set({ activityLog: log });
  });
}

function _persist() {
  chrome.storage.local.set({
    sessions:    _sessions,
    locks:       _locks,
    activeSiteId:_activeSiteId,
    sites:       SITES.map(s => ({ id:s.id, name:s.name, icon:s.icon })),
    lockRemaining: _getLockRemaining()
  });
}

// ── Message handler (from popup) ─────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type === 'GET_STATE') {
    reply({
      sessions:     _sessions,
      locks:        _getLockRemaining(),
      activeSiteId: _activeSiteId,
      sites:        SITES.map(s => ({ id:s.id, name:s.name, icon:s.icon })),
    });
  }
  if (msg.type === 'RESET_SITE') {
    delete _sessions[msg.siteId];
    delete _locks[msg.siteId];
    if (_activeSiteId === msg.siteId) _activeSiteId = null;
    _persist();
    reply({ ok: true });
  }
  if (msg.type === 'UNLOCK_SITE') {
    delete _locks[msg.siteId];
    if (_sessions[msg.siteId]) {
      _sessions[msg.siteId].elapsed   = 0;
      _sessions[msg.siteId].warnState = 'normal';
    }
    _persist();
    reply({ ok: true });
  }
  return true;
});
