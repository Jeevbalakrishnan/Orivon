# ⚡ ORIVON — Chrome Extension

Automatically detects when you open YouTube, Instagram, Facebook, TikTok, Twitter, Reddit, or Twitch — and starts tracking time immediately. No clicking required.

---

## How to Install (takes 1 minute)

1. **Open Chrome** and go to: `chrome://extensions`
2. **Enable Developer Mode** — toggle in the top-right corner
3. Click **"Load unpacked"**
4. Select the `orivon-extension` folder
5. Done ✅ — The Orivon icon appears in your toolbar

---

## How It Works

| Event | Trigger |
|-------|---------|
| Timer starts | You open/switch to YouTube, Instagram, etc. |
| Timer pauses | You switch to a non-monitored tab |
| ⏰ Reminder | 30 seconds on the site |
| ⚠️ Warning | 50 seconds — banner appears ON the page |
| 🚫 Block | 60 seconds — redirected to Orivon block page |
| 🔒 Lock | Blocked for 5 minutes (persists across tabs) |

---

## Monitored Sites
- YouTube
- Instagram
- Facebook
- TikTok
- Twitter / X
- Reddit
- Twitch

---

## Popup Dashboard
Click the ⚡ icon in Chrome toolbar to see:
- Which site is currently being tracked
- Live timer per site
- Addiction score
- Activity log

---

## Permissions Used
- `tabs` — to detect which URL is open
- `storage` — to save timers and locks
- `notifications` — to show system alerts

---

*Orivon — Real protection, not simulation.*
